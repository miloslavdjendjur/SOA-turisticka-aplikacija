import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as L from 'leaflet';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  private readonly API = 'http://localhost:8000';

  // MAPA
  private map: any;
  private marker: any;

  // STANJE
  currentUserId: number | null = null;
  message: string = '';
  activeTab: string = 'users';

  // PODACI - SADA SU PRAZNI (DA VIDIMO DA LI RADI UNOS)
  loginId: number | null = null;
  
  // 1. KORISNIK
  registerData = { username: '', password: '', email: '', role: 'TOURIST', name: '', surname: '' };
  userProfile: any = null;

  // 2. TURA
  tourData = { authorId: 0, name: '', description: '', difficulty: 'EASY', tags: ['ispit'], price: 0, distance: 0 };
  tours: any[] = [];

  // 3. KLJUCNA TACKA
  keyPointData = { tourId: 0, name: '', description: '', latitude: 45.2671, longitude: 19.8335, image: 'url', order: 1 };

  // 4. BLOG
  blogData = { authorId: 0, title: '', description: '', image: '' };
  blogs: any[] = [];

  // 5. FOLLOW
  followId: number | null = null;
  followingList: number[] = [];

  // 6. SIMULATOR
  simulator = { latitude: 45.2671, longitude: 19.8335 };

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadTours();
    this.loadBlogs();
  }

  // --- MAPA ---
  setTab(tab: string) {
    this.activeTab = tab;
    if (tab === 'tours') {
      setTimeout(() => { this.initMap(); }, 100);
    }
  }

  initMap() {
    if (this.map) return;
    this.map = L.map('map').setView([45.2671, 19.8335], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: 'OpenStreetMap'
    }).addTo(this.map);

    this.map.on('click', (e: any) => {
      const lat = e.latlng.lat;
      const lng = e.latlng.lng;
      
      this.simulator.latitude = lat;
      this.simulator.longitude = lng;
      this.keyPointData.latitude = lat;
      this.keyPointData.longitude = lng;

      if (this.marker) this.marker.setLatLng([lat, lng]);
      else this.marker = L.circleMarker([lat, lng], { radius: 8, color: 'red' }).addTo(this.map);
    });
  }

  // --- FUNKCIJE ---
  login() {
    if (!this.loginId) return;
    this.currentUserId = this.loginId;
    this.message = `👋 Ulogovan ID: ${this.loginId}`;
    this.getProfile();
  }

  register() {
    console.log("Šaljem podatke:", this.registerData); // <--- OVO GLEDAJ U KONZOLI (F12)
    this.http.post(`${this.API}/api/users/register`, this.registerData).subscribe({
      next: (res: any) => {
        this.currentUserId = res.id;
        this.loginId = res.id;
        this.message = `✅ Registrovan ID: ${res.id}`;
        this.getProfile();
      },
      error: (err) => this.message = `❌ Greška: ${err.error || err.message}`
    });
  }

  getProfile() {
    if(!this.currentUserId) return;
    this.http.get(`${this.API}/api/users/${this.currentUserId}`).subscribe({
      next: (res) => this.userProfile = res,
      error: (err) => this.message = "⚠️ Profil nije nađen."
    });
  }

  updateProfile() {
    if(!this.currentUserId) return;
    this.http.put(`${this.API}/api/users/${this.currentUserId}`, this.userProfile).subscribe({
      next: () => this.message = "✅ Profil ažuriran!",
      error: (err) => this.message = "❌ Greška update."
    });
  }

  createBlog() {
    if(!this.currentUserId) return;
    this.blogData.authorId = this.currentUserId;
    this.http.post(`${this.API}/blogs`, this.blogData).subscribe({
      next: () => { this.message = "✅ Blog objavljen!"; this.loadBlogs(); },
      error: (err) => this.message = `❌ Greška: ${err.message}`
    });
  }

  loadBlogs() {
    this.http.get<any[]>(`${this.API}/blogs`).subscribe(data => this.blogs = data);
  }

  followUser() {
    if(!this.currentUserId || !this.followId) return;
    this.http.post(`${this.API}/followers`, { followerId: this.currentUserId, followedId: this.followId }).subscribe({
      next: () => { 
        this.message = `✅ Pratiš ID ${this.followId}`; 
        this.followingList.push(this.followId!);
      },
      error: (err) => this.message = `❌ Greška: ${err.message}`
    });
  }

  createTour() {
    if(!this.currentUserId) return;
    this.tourData.authorId = this.currentUserId;
    this.http.post(`${this.API}/tours`, this.tourData).subscribe({
      next: () => { this.message = "✅ Tura kreirana!"; this.loadTours(); },
      error: (err) => this.message = `❌ Greška: ${err.message}`
    });
  }

  addKeyPoint() {
    if(!this.keyPointData.tourId) { this.message = "⚠️ Unesi ID ture!"; return; }
    this.http.post(`${this.API}/keypoints`, this.keyPointData).subscribe({
      next: () => this.message = "✅ Tačka dodata!",
      error: (err) => this.message = `❌ Greška: ${err.message}`
    });
  }

  updatePosition() {
    if(!this.currentUserId) return;
    this.http.post(`${this.API}/position`, { touristId: this.currentUserId, ...this.simulator }).subscribe({
      next: () => this.message = "📍 Pozicija ažurirana!",
      error: (err) => this.message = `❌ Greška: ${err.message}`
    });
  }

  buyTour(tourId: number) {
    if(!this.currentUserId) { this.message = "⚠️ Nisi ulogovan!"; return; }
    this.http.post(`${this.API}/tours/purchase`, { touristId: this.currentUserId, tourId }).subscribe({
      next: () => this.message = `💰 Kupljeno!`,
      error: (err) => this.message = `❌ Greška: ${err.message}`
    });
  }

  startTour(tourId: number) {
    if(!this.currentUserId) return;
    this.http.post(`${this.API}/tours/start`, { touristId: this.currentUserId, tourId }).subscribe({
      next: () => this.message = `🚀 Tura pokrenuta!`,
      error: (err) => this.message = `❌ Greška: ${err.error.error || err.message}`
    });
  }

  loadTours() {
    this.http.get<any[]>(`${this.API}/tours`).subscribe(data => this.tours = data);
  }
}